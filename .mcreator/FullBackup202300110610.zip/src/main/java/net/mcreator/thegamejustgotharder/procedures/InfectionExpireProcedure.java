package net.mcreator.thegamejustgotharder.procedures;

import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.eventbus.api.Event;
import net.minecraftforge.event.TickEvent;

import net.minecraft.world.phys.Vec3;
import net.minecraft.world.phys.Vec2;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import net.minecraft.commands.CommandSourceStack;
import net.minecraft.commands.CommandSource;

import net.mcreator.thegamejustgotharder.init.TheGameJustGotHarderModMobEffects;

import javax.annotation.Nullable;

@Mod.EventBusSubscriber
public class InfectionExpireProcedure {
	@SubscribeEvent
	public static void onPlayerTick(TickEvent.PlayerTickEvent event) {
		if (event.phase == TickEvent.Phase.END) {
			execute(event, event.player.level, event.player.getX(), event.player.getY(), event.player.getZ(), event.player);
		}
	}

	public static void execute(LevelAccessor world, double x, double y, double z, Entity entity) {
		execute(null, world, x, y, z, entity);
	}

	private static void execute(@Nullable Event event, LevelAccessor world, double x, double y, double z, Entity entity) {
		if (entity == null)
			return;
		if ((entity instanceof LivingEntity _livEnt && _livEnt.hasEffect(TheGameJustGotHarderModMobEffects.INFECTION.get()) ? _livEnt.getEffect(TheGameJustGotHarderModMobEffects.INFECTION.get()).getDuration() : 0) == 1) {
			if (entity instanceof LivingEntity _entity)
				_entity.hurt(new DamageSource("infection").bypassArmor(), 999999999);
			if (world instanceof ServerLevel _level)
				_level.getServer().getCommands().performPrefixedCommand(new CommandSourceStack(CommandSource.NULL, new Vec3(x, y, z), Vec2.ZERO, _level, 4, "", Component.literal(""), _level.getServer(), null).withSuppressedOutput(),
						("/summon zombie ~ ~1 ~ {PersistenceRequired:1,ArmorItems:[{},{},{},{Count:1,id:player_head,tag:{display:{Name:\"\\\"Player\\\"\"}}}],CustomName:\"\\\"\u00A7rPlayer\\\"\"}".replace("Player",
								entity.getDisplayName().getString())));
		}
	}
}
