
/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.thegamejustgotharder.init;

import net.minecraftforge.registries.RegistryObject;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.DeferredRegister;

import net.minecraft.world.item.Item;

import net.mcreator.thegamejustgotharder.item.BandageItem;
import net.mcreator.thegamejustgotharder.item.AntidoteItem;
import net.mcreator.thegamejustgotharder.TheGameJustGotHarderMod;

public class TheGameJustGotHarderModItems {
	public static final DeferredRegister<Item> REGISTRY = DeferredRegister.create(ForgeRegistries.ITEMS, TheGameJustGotHarderMod.MODID);
	public static final RegistryObject<Item> BANDAGE = REGISTRY.register("bandage", () -> new BandageItem());
	public static final RegistryObject<Item> ANTIDOTE = REGISTRY.register("antidote", () -> new AntidoteItem());
}
